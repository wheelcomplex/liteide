<!-- Forever -->

Forever
=======
## 2015.2.4
佛祖问阿难：你有多喜欢这少女? 阿难说：我愿化身石桥，受五百年风吹，五百年日晒，五百年雨打，但求此少女从桥上走过。

## 2014.10.10
天行健，君子以自强不息。地势坤，君子以厚德载物。

![](images/liteide.png)

## 2013.01.26

![](images/liteide400.png)

## 2012.10.10

![](images/flamingo.png)

## 2011.10.10
![](images/forever.png)

