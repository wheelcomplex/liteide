LiteIDE Color Scheme
===================

### item name

* fb foreground,background
* f foreground
* b background

**base color**

	Text		(fb)
	Extra		(fb)
	Selection	(fb)
	CurrentLine (b)
	IndentLine  (f)

**kate color:** (f,bold,italic)

	VisualWhitespace
	Keyword
	DataType
	Decimal
	BaseN
	Float
	Char
	String
	Comment
	Alert
	Error
	Function
	RegionMarker
	Symbol
	BuiltinFunc
	Predeclared
	FuncDecl
	Placeholder
	ToDo

### item attribute

	foreground
	background
	bold
	italic

### item example

	<style name="Keyword" foreground="#000000" background="#ffffff" bold="true" italic="true"/>
